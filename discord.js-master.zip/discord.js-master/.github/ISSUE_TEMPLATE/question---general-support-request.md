---
name: Question / General support request
about: Ask for help in Discord instead - https://discord.gg/bRCvFy9

---

Seriously, we only use this issue tracker for bugs in the library itself and feature requests for it.
We don't typically answer questions or help with support issues here.
Instead, please ask in one of the support channels in our Discord server:

https://discord.gg/bRCvFy9

Any issues that don't directly involve a bug in the library or a feature request will likely be closed and redirected to the Discord server.
